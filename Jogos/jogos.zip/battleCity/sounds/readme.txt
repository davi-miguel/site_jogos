bullet_brick_hit.wav: bullet hits and damages brick wall
bullet_wall_hit.wav: bullet hits wall or steel brick
enemy_destroyed.wav: enemy tank destroyed
enemy_hit.wav: enemy tank hit (but not destroyed!)
extra_life.wav: player gets extra tank (powerup or kills?)
pause.wav: game paused
player_destroyed.wav: player or flag destroyed
powerup_pickup.wav: powerup picked up (except for extra life)
powerup_spawned.wav: powerup spawns
score_tally_beep.wav: beeps at end of level for each kill made in stage
tank_idle.wav: player tank is standing still (loops?)
tank_move.wav: player tank is moving (loops?)
