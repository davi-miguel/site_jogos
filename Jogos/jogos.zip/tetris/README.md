# Tetris

Um jogo de tetris desenvolvido com JavaScript

Esse código é do [tutorial feito no meu canal do YouTube](https://www.youtube.com/watch?v=F9AZkz9QPpA&t=3562s&ab_channel=SenhorProgramador)
