# eclipse
Jogo de tiro Sci-Fi com Javascript vanilla, HTML e CSS

A proposta aqui é criar um jogo meio abstrato, mas com cara de Sci-Fi, no qual o jogador deve se defender contra inimigos invasores disparando projéteis na direção do ponteiro do mouse.

Neste projeto foi usado HTML, CSS e JavaScript vanilla (linguagem pura, sem bibliotecas ou frameworks) e apenas desenhos feitos no próprio canvas.

Todo o desenvolvimento deste projeto pode ser acompanhado no YouTube. [Acesse aqui playlist do projeto](https://www.youtube.com/playlist?list=PLclUTiUoLCbDHjxnd4FyliJuVeHS22pAK)

Este projeto é inspirado no jogo desenvolvido pelo canal [Chris Courses](https://www.youtube.com/c/ChrisCourses).

Clique [aqui](https://youtu.be/eI9idPTT0c4) para conhecer o projeto original e apoiar quem cria conteúdo gratuito com qualidade.
